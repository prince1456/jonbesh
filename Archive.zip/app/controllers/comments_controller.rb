class CommentsController < ApplicationController
  def create
    

  end
  def update


  end


end
