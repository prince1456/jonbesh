class Comment < ApplicationRecord
  belongs_to :report
end
