class Image < ApplicationRecord


end
